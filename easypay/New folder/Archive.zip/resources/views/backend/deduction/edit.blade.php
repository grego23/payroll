@extends('layouts.dashlay')

@section('content')
    <!-- [ Main Content ] start -->
    <section class="pcoded-main-container">
        <div class="pcoded-wrapper">
            <div class="pcoded-content">
                <div class="pcoded-inner-content">
                    <!-- [ breadcrumb ] start -->
                    <div class="page-header">
                        <div class="page-block">
                            <div class="row align-items-center">
                                <div class="col-md-12">
                                    <div class="page-header-title">
                                        <h5 class="m-b-10"> Edit Information</h5>
                                    </div>
                                    <ul class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="index.html"><i class="feather icon-home"></i></a></li>
                                        
                                        <li class="breadcrumb-item"><a href="company-info.html">Edit Deduction</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- [ breadcrumb ] end -->
                    <div class="main-body">
                        <div class="page-wrapper">
                            <!-- [ Main Content ] start -->
                            <div class="row">
                                <div class="col-sm-12">
                                                         
        <div class="alert alert-success" id="suc">
             <div class="writeinfo" style="font-weight:bold;"></div>  
        </div>
		         @if ($message = Session::get('message'))
        <div class="alert alert-success">
            <p>{{ $message }}</p>
        </div>
    @endif
  
             
                                </div>
								
								   <div class="col-md-12 col-xl-12">
                                    <div class="card user-card">
                                        <div class="card-block">
										
									{{Form::model($post,array('route'=>array('deduction.update',$post->id),'class'=>'form','method'=>'put','role'=>'form','files'=>true))}} 
 @csrf @method('PUT') 
                                       
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label class="form-label">Employee Id</label>
                                                           {{Form::text('emp_id',null,array('class'=>'form-control'))}} 
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label class="form-label">Personal Relief</label>
                                                             {{Form::text('personal_relief',null,array('class'=>'form-control'))}} 
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label class="form-label">Insurance Relief</label>
                            {{Form::text('insurance_relief',null,array('class'=>'form-control'))}} 
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label class="form-label">Pension Fund</label>
                                                            {{Form::text('pension_fund',null,array('class'=>'form-control'))}} 
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label class="form-label">Hosp</label>
                                                             {{Form::text('hosp',null,array('class'=>'form-control'))}} 
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label class="form-label">Occupier Interest</label>
                                                             {{Form::text('occupier_interest ',null,array('class'=>'form-control'))}} 
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label class="form-label">Disability Excemption</label>
															{{Form::text('disability_excemption',null,array('class'=>'form-control'))}} 
                                                           
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label class="form-label">Nhif Deduction</label>
															 {{Form::text('nhif_deduction',null,array('class'=>'form-control'))}} 
                                                           
                                                        </div>
                                                    </div>
                                                    
                                                    
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label class="form-label">Nssf Deduction</label>
															{{Form::text('nssf_deduct',null,array('class'=>'form-control'))}} 
                                                          
                                                    </div>
													</div>
                                                    
                                                    
                                                    
                                                </div>
                                                <button type="submit" class="btn btn-primary"  >Submit</button>
                                            </form>
										
            
            </div>
                                    </div>
                                </div>  
                              
                            </div>
                            <!-- [ Main Content ] end -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


	
	


  

@endsection






