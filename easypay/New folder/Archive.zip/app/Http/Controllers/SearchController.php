<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use \App\User;

use DB;

class SearchController extends Controller
{
    public function search(Request $request){
      $search=$request->get('search');

      
      //$users = User::whereRaw('date(created_at) = ?', [date($search)])->get();
      $users=User::where( DB::raw('MONTH(created_at)'), '=', date($search) )->get();
      dd($users);

    
    }
}
